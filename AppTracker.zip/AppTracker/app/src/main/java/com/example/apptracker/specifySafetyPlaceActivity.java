package com.example.apptracker;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class specifySafetyPlaceActivity extends AppCompatActivity {

    EditText range;
    Button back,save;
    DatabaseReference databaseReference;
    SafePlace safePlace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specify_safety_place);

        range = findViewById(R.id.textView8);
        back = findViewById(R.id.button8);
        save = findViewById(R.id.button7);
        safePlace = new SafePlace();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("SafePlace");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rng = Integer.parseInt(range.getText().toString().trim());

                safePlace.setRange(rng);

                databaseReference.push().setValue(safePlace);

                Toast.makeText(specifySafetyPlaceActivity.this, "Range Saved As "+rng+" metre", Toast.LENGTH_SHORT).show();

                Intent spcfy = new Intent(specifySafetyPlaceActivity.this,specifySafetyPlaceActivity.class);
                startActivity(spcfy);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(specifySafetyPlaceActivity.this,HomeActivity.class);
                startActivity(back);
            }
        });
    }
}