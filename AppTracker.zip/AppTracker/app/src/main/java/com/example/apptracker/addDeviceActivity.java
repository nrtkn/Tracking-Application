package com.example.apptracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class addDeviceActivity extends AppCompatActivity {

    EditText namePat,surPat;
    Button btnAdd;
    DatabaseReference databaseReference;
    Patient patient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device);

        namePat = findViewById(R.id.textView6);
        surPat = findViewById(R.id.textView7);
        btnAdd = findViewById((R.id.button5));
        patient = new Patient();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Patient");



        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                patient.setPatName(namePat.getText().toString().trim());
                patient.setPatSurname(surPat.getText().toString().trim());


                databaseReference.push().setValue(patient);

                Intent intToAdd = new Intent(addDeviceActivity.this,HomeActivity.class);
                startActivity(intToAdd);
            }
        });

    }

    private void showToast(String add) {
        Toast.makeText(addDeviceActivity.this,add,Toast.LENGTH_SHORT).show();
    }

}