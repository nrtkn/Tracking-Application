package com.example.apptracker;


public class SafePlace {
    private int range;

    public SafePlace() {
    }

    public int getRange() {
        return range;
    }

    public void setRange(int range) {
        this.range = range;
    }
}